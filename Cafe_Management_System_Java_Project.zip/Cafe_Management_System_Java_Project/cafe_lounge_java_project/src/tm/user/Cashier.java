package tm.user;

public class Cashier extends User{


    public Cashier(String userName, String email, String password, String userType) {
        super(userName, email, password, userType);
    }
}
