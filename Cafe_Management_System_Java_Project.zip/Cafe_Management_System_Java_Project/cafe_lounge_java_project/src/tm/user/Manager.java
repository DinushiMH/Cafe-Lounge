package tm.user;

public class Manager extends User{
    public Manager(String userName, String email, String password, String userType) {
        super(userName, email, password, userType);
    }
}
