package tm.item;

public class Burger extends item {
    public Burger(String name, String manufacture, double price, int quantity, String category) {
        super(name, manufacture, price, quantity, category);
    }
}
