package tm.item;

public class Beverages extends item {
    public Beverages(String name, String manufacture, double price, int quantity, String category) {
        super(name, manufacture, price, quantity, category);
    }
}
