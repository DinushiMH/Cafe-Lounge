package tm.item;

public class Cakes extends item {
    public Cakes(String name, String manufacture, double price, int quantity, String category) {
        super(name, manufacture, price, quantity, category);
    }
}
