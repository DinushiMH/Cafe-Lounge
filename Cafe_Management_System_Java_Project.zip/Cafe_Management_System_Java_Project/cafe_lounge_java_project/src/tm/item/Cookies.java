package tm.item;

public class Cookies extends item {
    public Cookies(String name, String manufacture, double price, int quantity, String category) {
        super(name, manufacture, price, quantity, category);
    }
}
